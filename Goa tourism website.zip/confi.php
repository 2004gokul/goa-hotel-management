<?php 
 
 $con = mysqli_connect("localhost","root","","tutoria") or die("Couldn't connect");

?>