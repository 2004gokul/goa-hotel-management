<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="por.css">
</head>

        <div class="bg-container">
            <div class="text-center mt-5">
                <h1 class="hi">View Contact</h1>
                <hr style="background-color: white; height: 1px; width: 1300px;">
            </div>
            <div class="container fff">
                <div class="row">
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class=" d-flex flex-column text-center ml-4">
                            <img src="jana.jpeg" class="logo-image mb-3 ml-4" />
                            <div class="d-flex flex-row mb-4">
                                <div class="icon-container mr-2">
                                    <img src="https://www.mediaite.com/wp-content/uploads/2018/10/twitter.jpg" class="icon-container">
                                </div>
                                <div class="icon-container mr-2">
                                    <img src="https://th.bing.com/th/id/OIP.TGlDU1ghKS2IIYWutiA01QHaHa?pid=ImgDet&rs=1" class="icon-container">
                                </div>
                                <div class="icon-container mr-2">
                                    <img src="https://cdn.pixabay.com/photo/2017/10/04/11/58/facebook-2815970_960_720.jpg" class="icon-container">
                                </div>
                                <div class="icon-container mr-2">
                                    <img src="https://pngimg.com/uploads/linkedIn/linkedIn_PNG39.png" class="icon-container">
                                </div>
                            </div>
                            <p class="adress">1/84,Street,Baga,Goa,India-405238</p>
                        </div>
                    </div>
    
                    <div class="col-6 col-md-6 col-lg-3">
                        <div class="gg">
                            <h1 class="card-headings mb-3">Get to know me</h1>
                            <p class="card-description">About us</p>
                            <p class="card-description">Career</p>
                            <p class="card-description">Press Releases</p>
                            <p class="card-description">Services</p>
                             </div>
                    </div>
    
                    <div class="col-6 col-md-6 col-lg-3">
                        <div>
                            <h1 class="card-headings mb-3">Contact with us</h1>
                            <p class="card-description">Facebook</p>
                            <p class="card-description">Twitter</p>
                            <p class="card-description">Instagram</p>
                        </div>
                    </div>
    
                    <div class="col-6 col-md-6 col-lg-3">
                        <div>
                            <h1 class="card-headings mb-3">Information</h1>
                            <p class="card-description">3/5 Rating</p>
                            <p class="card-description">Baga-Goa</p>
                            <p class="card-description">9994122706</p>
                            <p class="card-description">gokulsjana@gmail.com</p>
                            <p class="card-description">College-coimbatore institute of technology</p>
                            
                        </div>
                    </div>
                    <hr style="background-color: white; height: 1px; width: 1350px;">
                    <div class="d-flex flex-row justify-content-center ml-5 col-lg-3">
                        <i class="fas fa-copyright copy-right mr-2" aria-hidden="true"></i>
                        <p class="card-description">by Gokul Sri . Coder,Developer</p>
                    </div>   
                </div>
                <div class="mt-1">
                   <a href="home.php"> <button class="btn btn-light nvn">Back</button></a>
                </div>
            </div>
        </div>
   
    <script type="text/javascript" src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-static-website/js/ccbp-ui-kit.js"></script>
</body>

</html>