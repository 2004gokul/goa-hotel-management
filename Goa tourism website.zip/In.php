<?php 
@include 'config.php';
$result = mysqli_query($con,"SELECT * FROM users ") or die("Select Error");

?> 
<!DOCTYPE html> 
<html> 
	<head> 
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="po.css">
		<title> Fetch Data From Database </title> 
		<style>
    table,
   {
        border: 1px solid black;
		background-color:#88c7dc;
		padding:10px;
		text-align:center;
    }
	th{ border: 1px solid black;
		background-color:#88c7dc;
		padding:10px;
		text-align:center;
		font-family:"Cooper";
		font-size:20px;

	}
		td{ border: 1px solid black;
		background-color:#88c7dc;
		padding:10px;
	    color:grey;
		font-size:17px;
}
.hjhp{
	color:#1E2F97;
	font-family:"Cooper";
}
		
    </style>
	</head> 
	<body> 
		<div class="zxzx">
	<table  style="width:600px;"> 
	<tr> 
		<th colspan="5"><h2 class="hjhp">Customer Record</h2></th> 
		</tr> 
			  <th> ID </th> 
			  <th> Username </th> 
			  <th> Email </th> 
			  <th> Age </th> 
			  <th>option to Delete</th>
			  
		</tr> 
		
		<?php while($row = mysqli_fetch_assoc($result)) 
		{ 
		?> 
		<tr> <td><?php echo $row['Id']; ?></td> 
		<td><?php echo $row['Username']; ?></td> 
		<td><?php echo $row['Email']; ?></td> 
		<td><?php echo $row['Age']; ?></td> 
		<td>
            <form method="post" action="delete.php"> 
                <input type="hidden" name="id" value="<?php echo $row['Id']; ?>"> 
                <input type="submit" value="Delete" class="btn btn-danger">
            </form>
        </td>
		</tr> 
	<?php 
               } 
          ?> 

	</table> 
	<div class="mt-5">
		<a href="admin_page.php"><button class="btn btn-warning">Back</button></a>
	</div>
	</div>
	</body> 
	</html>