
<!DOCTYPE html>
<html>

<head>
    
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="po.css">
    <script>
    
    </script>
</head>

<body>
        <div class="loo">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="p-2 vb mt-5 mb-5 shadow d-flex flex-row">
                            <div class="nln">
                                <h1 class="popp">Propert overview</h1>
                                <h1 class="popl">Air Conditioning</h1>
                                <h1 class="popl">Daily housekeeping</h1>
                                <h1 class="popl">garden</h1>
                                <hr class="bn">
                                <h1 class="popp">Nearby Attraction</h1>
                                <h1 class="popl">Baga Beach</h1>
                                <h1 class="popl">Calangute Beach</h1>
                                <h1 class="popl">Candolim Beach</h1>
                                <h1 class="popl">Basilica of Bom Jesus</h1>
                                <hr class="bn">
                                <h1 class="popp">Dinking,drinking and snacking</h1>
                                <h1 class="popl">Coffee/tea makwer</h1>
                                <h1 class="popl">Free bottled water</h1>
                                <h1 class="popl">Refrigerator</h1>
                                <hr class="bn">
                                <div class="text-center m-2">
                                   <a href="book.php"> <button class="btn btn-warning" >BOOK NOW</button><a>
                                   <a href="home.php"><button class="btn btn-success ml-5">Go Home</button></a>
                                </div>
                            </div>
                            <div class="liop">
                                <div class="d-flex flex-row">
                                    <div>
                                        <img src="http://pix10.agoda.net/hotelImages/247771/-1/99b4fb29835e47d1ab1f01d3b62e86ef.jpg" class="jok" />
                                    </div>
                                    <div>
                                        <img src="https://i.pinimg.com/736x/ac/d8/c7/acd8c7b3d88171d01160e6b0c04a0521--medium-india.jpg" class="jok" />
                                    </div>
                                    <div>
                                        <img src="https://pix10.agoda.net/hotelimages/247771/3142235/a7a6e4afc71425e224a0b9ab6ea660d5.jpeg?ce=0" class="jok" />
                                    </div>
                                </div>
                                <div class="d-flex flex-row">
                                    <div>
                                        <img src="https://pix10.agoda.net/hotelImages/247/247771/247771_15082714590035191279.jpg?s=1024x768" class="jok" />
                                    </div>
                                    <div>
                                        <img src="https://images.trvl-media.com/hotels/5000000/4290000/4282700/4282617/f80bef7e.jpg" class="jok" />
                                    </div>
                                    <div>
                                        <img src="https://photos.hotelbeds.com/giata/xxl/14/140710/140710a_hb_p_013.jpg" class="jok" />
                                    </div>
                                </div>
                                <div class="d-flex flex-row">
                                    <div>
                                        <img src="https://imgcld.yatra.com/ytimages/image/upload/t_hotel_yatra_details_desktop/v1432040428/Domestic%20Hotels/Hotels_Goa/Resort%20Primo%20Bom%20Terra%20Verde/Guesthouse.jpg" class="jok" />
                                    </div>
                                    <div>
                                        <img src="https://pix10.agoda.net/hotelImages/247/247771/247771_17092618500056821186.jpg" class="jok" />
                                    </div>
                                    <div>
                                        <img src="https://primovenues.com/wp-content/uploads/2017/03/Great-outdoor-view-Poracay-Resort-768x511.jpg" class="jok" />
                                    </div>
                                </div>
                                <div class="d-flex flex-row">
                                    <div>
                                        <img src="https://primovenues.com/wp-content/uploads/2017/05/Best-pool-place-88-Hotspring-Resort-1024x683.jpg" class="jok" />
                                    </div>
                                    <div>
                                        <img src="https://primovenues.com/wp-content/uploads/2017/02/Glamorous-events-venue-Pearl-Farm-Beach-Resort-768x512.jpg" class="jok" />
                                    </div>
                                    <div>
                                        <img src="https://primovenues.com/wp-content/uploads/2017/05/Great-place-Palmridge-Private-Resort-1024x643.jpg" class="jok" />
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="text-right">
                        
                    
                    </div>
                </div>
            </div>
        </div>

</body>  
</html>
