<?php
@include 'config.php';

if(isset($_POST['id'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM users WHERE Id='$id'";
    if (mysqli_query($con, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($con);
    }

    mysqli_close($con);
}

header("Location:in.php"); 
?>